function DDDF = third_der_hyper(~, ~,~,~)
% function DDDF = third_der_hyper(x, v1,v2,v3)
%
% independent of inputs, because second order system. Actually, null
% derivative.
DDDF=zeros(4,1);