function DDDF = third_der_Lorenz84(~, ~,~,~)
% function DDDF = third_der_Lorenz84(x, v1,v2,v3)
%
% independent of inputs, because second order system. Actually, null
% derivative.
DDDF=zeros(4,1);