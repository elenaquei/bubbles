str = "partial_FHN_simplex_validation";
for k=1:200
    load(append(str,num2str(k)));
    scalar_vars = [2,3,4];          % Parameter1, Parameter2, Amplitude.
    colour = 'b';                   % The simplices are validated; they are blue.
    EdgeAlpha = 0;                  % Do not plot edges.
    plot(list_of_simplices,list_of_nodes,1:length(list_of_simplices),colour,scalar_vars,EdgeAlpha);
    hold
end