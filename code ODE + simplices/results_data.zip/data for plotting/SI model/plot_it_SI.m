str = "SI_model_data_iter";
for k=1:10
    load(append(str,num2str(k)));
    scalar_vars = [6,5,3];      % R0, p, amplitude.
    colour = 'b';               % The simplices are validated; they are blue. 
    plot(list_of_simplices,list_of_nodes,1:length(list_of_simplices),colour,scalar_vars);
    hold
end