load("fish.mat")
subplot(1,2,1)
% Plot the usual projection.
plot(list_of_simplices,list_of_nodes)
subplot(1,2,2)
% Plot the projection with z_3(0) on vertical axis.
scalar_vars = [2,3,NaN];        % Parameter1, Parameter2, NotApplicable.
vector_sum_vars = [NaN,NaN,3];  % NotApplicable, NotApplicable, Vector_Variable3.
colour = 'b';                   % The simplices are validated; they are blue.
EdgeAlpha = 1;                  % Plot the simplex edges.
plot(list_of_simplices,list_of_nodes,1:length(list_of_simplices),colour,scalar_vars,EdgeAlpha,vector_sum_vars)